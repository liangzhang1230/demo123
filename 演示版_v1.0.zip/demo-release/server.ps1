# 演示版静态服务器（零依赖 · 端口 5188 · 局域网可访问）
$port = 5188
$root = Join-Path $PSScriptRoot 'dist'
$mime = @{ '.html'='text/html; charset=utf-8'; '.js'='text/javascript'; '.css'='text/css';
  '.svg'='image/svg+xml'; '.png'='image/png'; '.jpg'='image/jpeg'; '.json'='application/json';
  '.ico'='image/x-icon'; '.woff2'='font/woff2'; '.webm'='video/webm' }
$ips = (Get-NetIPAddress -AddressFamily IPv4 -ErrorAction SilentlyContinue |
  Where-Object { $_.IPAddress -notlike '127.*' -and $_.IPAddress -notlike '169.254.*' }).IPAddress
Write-Host ''
Write-Host '================ AI 销售操盘手 · 演示版 ================'
Write-Host " 本机访问： http://localhost:$port/"
foreach ($ip in $ips) { Write-Host " 手机访问： http://$($ip):$port/   （手机与电脑同一 WiFi/热点）" }
Write-Host ' 按 Ctrl+C 或直接关窗口即停止'
Write-Host '========================================================'
$listener = [System.Net.Sockets.TcpListener]::new([System.Net.IPAddress]::Any, $port)
try { $listener.Start() } catch { Write-Host "端口 $port 被占用，请关闭占用程序后重试"; Read-Host '回车退出'; exit 1 }
Start-Process "http://localhost:$port/"
while ($true) {
  $client = $listener.AcceptTcpClient()
  try {
    $stream = $client.GetStream()
    $reader = New-Object IO.StreamReader($stream)
    $line = $reader.ReadLine()
    while (($l = $reader.ReadLine()) -and $l -ne '') { }
    $path = '/'
    if ($line -match '^GET\s+(\S+)') { $path = $Matches[1] }
    $path = $path.Split('?')[0].Split('#')[0]
    if ($path -eq '/') { $path = '/index.html' }
    $file = Join-Path $root ($path.TrimStart('/') -replace '/', '\')
    if (-not (Test-Path $file -PathType Leaf)) { $file = Join-Path $root 'index.html' }
    $bytes = [IO.File]::ReadAllBytes($file)
    $ext = [IO.Path]::GetExtension($file).ToLower()
    $ct = $mime[$ext]; if (-not $ct) { $ct = 'application/octet-stream' }
    $header = "HTTP/1.1 200 OK`r`nContent-Type: $ct`r`nContent-Length: $($bytes.Length)`r`nCache-Control: no-cache`r`nConnection: close`r`n`r`n"
    $hb = [Text.Encoding]::ASCII.GetBytes($header)
    $stream.Write($hb, 0, $hb.Length)
    $stream.Write($bytes, 0, $bytes.Length)
  } catch { } finally { $client.Close() }
}
