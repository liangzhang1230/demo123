#!/bin/bash
cd "$(dirname "$0")"
PORT=5188
IP=$(ipconfig getifaddr en0 2>/dev/null || ipconfig getifaddr en1 2>/dev/null || echo "本机IP")
echo ""
echo "================ AI 销售操盘手 · 演示版 ================"
echo " 本机访问： http://localhost:$PORT/"
echo " 手机访问： http://$IP:$PORT/   （手机与电脑同一 WiFi/热点）"
echo " 按 Ctrl+C 或直接关窗口即停止"
echo "========================================================"
( sleep 1; open "http://localhost:$PORT/" ) &
if command -v python3 >/dev/null 2>&1; then
  exec python3 -m http.server "$PORT" --directory dist --bind 0.0.0.0
else
  echo "未找到 python3——改用单文件应急版（仅本机）"
  open "dist-offline/index.html"
fi
